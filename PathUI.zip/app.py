from flask import Flask, render_template, jsonify
import pandas as pd

app = Flask(__name__)

def load_data():
    # Load the CSV file
    df = pd.read_csv('data.csv')
    return df

data = load_data()

def process_data():
    grouped_data = {}
    for group, group_df in data.groupby('Group'):
        stationary = group_df['Drive/Stationary'].iloc[0] == 'Stationary'
        if stationary:
            # Take one representative location
            lat, long = group_df[['Lat', 'Long']].iloc[0]
            activities = group_df[['timestamp', 'Activity']].to_dict(orient='records')
            grouped_data[group] = {'stationary': True, 'lat': lat, 'long': long, 'activities': activities}
        else:
            # Driving group - include all points
            path = group_df[['Lat', 'Long', 'Activity', 'timestamp']].to_dict(orient='records')
            grouped_data[group] = {'stationary': False, 'path': path}
    return grouped_data

grouped_data = process_data()

@app.route('/')
def index():
    return render_template('index.html', groups=grouped_data)

@app.route('/data')
def get_data():
    return jsonify(grouped_data)

if __name__ == '__main__':
    app.run(debug=True)

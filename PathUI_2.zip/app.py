from flask import Flask, render_template, jsonify
import pandas as pd

app = Flask(__name__)

# Load and process CSV file
def load_data():
    df = pd.read_csv("data.csv")

    # Define red events
    red_events = {"Call Drop", "Re-Establishment Failure", "UE Lost"}

    # Separate Drive and Stationary groups
    drive_data = df[df["Drive/Stationary"].str.contains("Drive", na=False)].copy()
    stationary_data = df[df["Drive/Stationary"] == "Stationary"].copy()

    # Aggregate Stationary Groups
    stationary_grouped = stationary_data.groupby("Group").agg({
        "Lat": "mean",
        "Long": "mean",
        "Activity": lambda x: list(x),
        "Tower Lat": "first",
        "Tower Long": "first"
    }).reset_index()

    # Assign color based on event type
    stationary_grouped["Color"] = stationary_grouped["Activity"].apply(
        lambda events: "red" if any(e in red_events for e in events) else "green"
    )

    # Extract unique tower locations
    towers = df[['Tower Lat', 'Tower Long', 'Tower Beamwidth', 'Tower Azimuth']].drop_duplicates().dropna()

    return drive_data.to_dict(orient="records"), stationary_grouped.to_dict(orient="records"), towers.to_dict(orient="records")

@app.route("/")
def index():
    return render_template("map.html")

@app.route("/get_data")
def get_data():
    drive_data, stationary_data, towers = load_data()
    return jsonify({"drive": drive_data, "stationary": stationary_data, "towers": towers})

if __name__ == "__main__":
    app.run(debug=True)
let map;

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 0, lng: 0 },
        zoom: 12,
    });

    fetch("/get_data")
        .then(response => response.json())
        .then(data => {
            plotEvents(data.drive, false);
            plotEvents(data.stationary, true);
            plotTowers(data.towers);
        });
}

function plotEvents(events, isStationary) {
    events.forEach(event => {
        let color = event.Color || (["Call Drop", "Re-Establishment Failure", "UE Lost"].includes(event.Activity) ? "red" : "green");
        
        let marker = new google.maps.Marker({
            position: { lat: event.Lat, lng: event.Long },
            map: map,
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: isStationary ? 10 : 5,
                fillColor: color,
                fillOpacity: 1,
                strokeWeight: 1,
            }
        });

        let infoContent = `<b>Events:</b> ${Array.isArray(event.Activity) ? event.Activity.join(", ") : event.Activity}`;
        let infowindow = new google.maps.InfoWindow({ content: infoContent });

        marker.addListener("click", () => infowindow.open(map, marker));

        if (!isStationary) {
            new google.maps.Polyline({
                path: [{ lat: event.Lat, lng: event.Long }, { lat: event["Tower Lat"], lng: event["Tower Long"] }],
                strokeColor: "#0000FF",
                strokeOpacity: 0.7,
                strokeWeight: 2,
                map: map,
            });
        }
    });
}

function plotTowers(towers) {
    towers.forEach(tower => {
        new google.maps.Marker({
            position: { lat: tower["Tower Lat"], lng: tower["Tower Long"] },
            map: map,
            icon: {
                path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW,
                scale: 6,
                fillColor: "blue",
                fillOpacity: 1,
                strokeWeight: 1,
            },
            title: `Tower: Beamwidth ${tower["Tower Beamwidth"]}, Azimuth ${tower["Tower Azimuth"]}`
        });

        plotTowerCoverage(tower);
    });
}

function plotTowerCoverage(tower) {
    let center = { lat: tower["Tower Lat"], lng: tower["Tower Long"] };
    let radius = 0.01; // Adjust as needed

    let sectorCoords = [
        center,
        computeOffset(center, radius, tower["Tower Azimuth"] - tower["Tower Beamwidth"] / 2),
        computeOffset(center, radius, tower["Tower Azimuth"] + tower["Tower Beamwidth"] / 2),
        center
    ];

    new google.maps.Polygon({
        paths: sectorCoords,
        strokeColor: "blue",
        strokeOpacity: 0.6,
        strokeWeight: 1,
        fillColor: "blue",
        fillOpacity: 0.2,
        map: map,
    });
}

function computeOffset(origin, distance, angle) {
    let earthRadius = 6378.1; // Radius in km
    let dRad = distance / earthRadius;
    let angleRad = angle * (Math.PI / 180);

    let lat1 = origin.lat * (Math.PI / 180);
    let lon1 = origin.lng * (Math.PI / 180);

    let lat2 = Math.asin(Math.sin(lat1) * Math.cos(dRad) + Math.cos(lat1) * Math.sin(dRad) * Math.cos(angleRad));
    let lon2 = lon1 + Math.atan2(Math.sin(angleRad) * Math.sin(dRad) * Math.cos(lat1), Math.cos(dRad) - Math.sin(lat1) * Math.sin(lat2));

    return { lat: lat2 * (180 / Math.PI), lng: lon2 * (180 / Math.PI) };
}

// Load the map
window.onload = initMap;
